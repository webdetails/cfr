/*!
* Copyright 2002 - 2013 Webdetails, a Pentaho company.  All rights reserved.
*
* This software was developed by Webdetails and is provided under the terms
* of the Mozilla Public License, Version 2.0, or any later version. You may not use
* this file except in compliance with the license. If you need a copy of the license,
* please go to  http://mozilla.org/MPL/2.0/. The Initial Developer is Webdetails.
*
* Software distributed under the Mozilla Public License is distributed on an "AS IS"
* basis, WITHOUT WARRANTY OF ANY KIND, either express or  implied. Please refer to
* the license for the specific language governing your rights and limitations.
*/

package pt.webdetails.cfr.file;

import java.io.File;

import junit.framework.Assert;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import pt.webdetails.cfr.CfrEnvironment;
import pt.webdetails.cfr.CfrEnvironmentForTests;
import pt.webdetails.cfr.persistence.PersistenceEngineForTests;
import pt.webdetails.cfr.repository.DefaultFileRepository;
import pt.webdetails.cpf.PluginEnvironment;
import pt.webdetails.cpf.persistence.PersistenceEngine;

public class FileStorerTest {

  @BeforeClass
  public static void setUp() throws Exception {
    PluginEnvironment.init( new CfrEnvironmentForTests() );
    PersistenceEngineForTests.getInstance().startOrient();
  }

  @AfterClass
  public static void setDown() throws Exception {
    PersistenceEngineForTests.getInstance().dropClass( FileStorer.FILE_METADATA_STORE_CLASS );
    PersistenceEngineForTests.getInstance().dropClass( FileStorer.FILE_PERMISSIONS_METADATA_STORE_CLASS );
  }

  @Before
  public void resetRepo() {
    PersistenceEngineForTests.getInstance().dropClass( FileStorer.FILE_METADATA_STORE_CLASS );
    PersistenceEngineForTests.getInstance().dropClass( FileStorer.FILE_PERMISSIONS_METADATA_STORE_CLASS );
    PersistenceEngineForTests.getInstance().initializeClass( FileStorer.FILE_METADATA_STORE_CLASS );
    PersistenceEngineForTests.getInstance().initializeClass( FileStorer.FILE_PERMISSIONS_METADATA_STORE_CLASS );
  }

  @Test
  public void testFileStorer() throws JSONException {
    FileStorer fs = new FileStorerForTests( new DefaultFileRepositoryForTests() );

    Assert.assertTrue( fs.storeFile( "t.txt", "my_test", new byte[50], "User" ) );

    PersistenceEngine pe = PersistenceEngineForTests.getInstance();
    JSONObject result = pe.query( "select from " + FileStorer.FILE_METADATA_STORE_CLASS, null );

    JSONArray resultArray = result.getJSONArray( "object" );
    Assert.assertEquals( 1, resultArray.length() );

    JSONObject resultElt = resultArray.getJSONObject( 0 );

    Assert.assertEquals( "User", resultElt.getString( "user" ) );
    Assert.assertEquals( "my_test" + File.separator + "t.txt", resultElt.getString( "file" ) );

  }

  @Test
  public void testFileStorerFailLoading() throws JSONException {
    FileStorer fs = new FileStorerForTests( new DefaultFileRepositoryForTests() );

    Assert.assertTrue( fs.storeFile( "t.txt", "my_test", new byte[50], "User" ) );

    fs = new FileStorerForTests( new DefaultFileRepositoryForTests( false ) );

    Assert.assertFalse( fs.storeFile( "t.txt", "my_test", new byte[50], "User" ) );

    PersistenceEngine pe = PersistenceEngineForTests.getInstance();
    JSONObject result = pe.query( "select from " + FileStorer.FILE_METADATA_STORE_CLASS, null );

    JSONArray resultArray = result.getJSONArray( "object" );
    Assert.assertEquals( 1, resultArray.length() ); // There should be only the result of the first test
  }

  public class DefaultFileRepositoryForTests extends DefaultFileRepository {

    private boolean result;

    public DefaultFileRepositoryForTests() {
      this.result = true;
    }

    public DefaultFileRepositoryForTests( boolean expectedResult ) {
      this.result = expectedResult;
    }

    @Override
    protected String getBasePath() {
      return "./test-resources";
    }

    @Override
    public boolean storeFile( byte[] content, String fileName, String relativePath ) {
      return this.result;
    }
  }

}
